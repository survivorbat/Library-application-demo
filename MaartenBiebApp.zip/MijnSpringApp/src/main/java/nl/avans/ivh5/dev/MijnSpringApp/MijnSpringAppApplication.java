package nl.avans.ivh5.dev.MijnSpringApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MijnSpringAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MijnSpringAppApplication.class, args);
	}
}
